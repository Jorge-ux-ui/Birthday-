function showSurprise() {
    var surprise = document.getElementById('surprise');
    surprise.style.display = 'block';
    document.querySelector('button').style.display = 'none';
}